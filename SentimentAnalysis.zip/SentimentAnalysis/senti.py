'''

pip install boto3
pip install awscli 
aws configure --profile Admin  
accesskey - AKIAR6SBPC7T7CBAL3N3
secret key - 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

Sentiment Analysis - NLP 
Polarity - positive,negative,neutral
Emotions - angry,happy,sad
Urgency - urgent,not urgent
Intentions - interested, not interested

Amazon Comprehend :
Derive and understand valuable insights from text within documents,customer support tickets, product reviews, emails, social media feeds
Simplify document processing workflows by extracting text, key phrases, language, pii, sentiment, entity from documents

Boto3 in Python :
Boto3 - Python SDK for AWS. It allows you to directly create, update, and delete AWS resources from your Python scripts.
'''

import tkinter as tk
import boto3


# root - handler for GUI window
root = tk.Tk()
root.geometry("400x240")
root.title("Sentiment Analysis by Amazon Comprehend")

#textExample - handler for text area
textExample = tk.Text(root,height=10)
textExample.pack()

def getText():
    aws_mgmt_console = boto3.session.Session(profile_name='Admin')              # Opening aws management console programmatically
    client = aws_mgmt_console.client(service_name='comprehend', region_name='ap-south-1')        
    result = textExample.get("1.0","end") # Read from 1st string till the end
    print(result)

    # Sending text result to comprehend 
    response = client.detect_sentiment(Text=result, LanguageCode='en')
    print(response) # dict format
    print('Response : ', response['Sentiment'])
    print('Sentiment Score : ', response['SentimentScore'])

btnRead = tk.Button(root,height=1,width=10,text='Read',command=getText) 
btnRead.pack()   

root.mainloop()  