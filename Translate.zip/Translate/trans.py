# MultiLingual

'''
Amazon Translate - Text translation service that uses advanced machine learning technologies
Translate unstructured text documents or to build applications that work in multiple languages
Based on Neural networks trained for language translation
Translate between source langauge to target language
Source text and Output text - UTF8 Format
'''

import tkinter as tk
import boto3

root = tk.Tk()
root.geometry('400x240')
root.title('AWS Translator')
textExample = tk.Text(root,height=10)
textExample.pack()

def getText():

    aws_mgmt_console = boto3.session.Session(profile_name='Admin')
    client = aws_mgmt_console.client(service_name='translate', region_name='ap-south-1')
    result = textExample.get('1.0','end')
    print(result)

    response=client.translate_text(Text=result,SourceLanguageCode='en',TargetLanguageCode='de')
    print('Translated Text: ' + response.get('TranslatedText'))
    print('Source Language Code: ' + response.get('SourceLanguageCode'))
    print('Target Language Code: ' + response.get('TargetLanguageCode'))

btnRead = tk.Button(root,height=1,width=10,text='Read',command=getText)
btnRead.pack()
root.mainloop()    