'''
Boto3
AWS Textract - Automatically extract printed text, handwriting, and data from any document
Extract text and structured data such as tables and forms from documents using artificial intelligence (AI)

Optical Character Recognition
Form Extraction
Table Extraction
Signature Detection
Query Based Extraction
Handwriting Recognition
Invoices and Receipts
'''

import boto3
import tkinter as tk
from tkinter import filedialog
from tkinter.filedialog import askopenfile
from PIL import Image,ImageTk


my_w = tk.Tk()
my_w.geometry('450x400')
my_w.title('AWS Textract')
my_font = ('times',18,'bold')

l1 = tk.Label(my_w, text='Upload an Image', width=30, font=my_font)
l1.pack()

b1 = tk.Button(my_w, text='Upload File', width=30, command=lambda:upload_file())
b1.pack()

def upload_file():

    global img

    aws_mgmt_console = boto3.session.Session(profile_name='Admin')              
    client = aws_mgmt_console.client(service_name='textract', region_name='ap-south-1') 
    
    f_types = [('Jpg Files', "*.jpg")]
    filename = filedialog.askopenfilename(filetypes=f_types)

    img = Image.open(filename)
    img_resize = img.resize((400,200))
    img = ImageTk.PhotoImage(img_resize)

    imgbytes = get_image_byte(filename) # Converting img into bytes

    b2 = tk.Button(my_w, image=img)
    b2.pack()

    response = client.detect_document_text(Document={'Bytes':imgbytes})
    for item in response['Blocks']:
        if item['BlockType'] == 'WORD':   # or 'PAGE'|'LINE'|'WORD'|'TABLE'|'CELL'|'SELECTION_ELEMENT'|'MERGED_CELL'|'TITLE'|'QUERY'|'QUERY_RESULT'|'SIGNATURE'|'TABLE_TITLE'
            print(item['Text'])

def get_image_byte(filename):
    with open(filename, 'rb') as imgfile:
        return imgfile.read()

my_w.mainloop()