# GUI for T2S Converter

""" 
pip install boto3
pip install awscli 
aws configure --profile Admin  
accesskey - AKIAR6SBPC7T7CBAL3N3
secret key - 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

GUI - Python Tkinter & Boto3
Amazon Polly – Text into life-like speech using Deep Learning (Machine Learning) 
"""


import tkinter as tk
import boto3
import os
import sys
from tempfile import gettempdir
from contextlib import closing      # opening file,extract stream,close file

# root - handler for GUI window
root = tk.Tk()
root.geometry("400x240")
root.title("T2S Coverter by Amazon Polly")

#textExample - handler for text area
textExample = tk.Text(root,height=10)
textExample.pack()

def getText():

    aws_mgmt_console = boto3.session.Session(profile_name='Admin')# Opening aws management console programmatically
    client = aws_mgmt_console.client(service_name='polly', region_name='ap-south-1')# Amazon Polly Console
    result = textExample.get("1.0","end") # Read from 1st string till the end
    print(result)
    response = client.synthesize_speech(Text=result, Engine='neural', OutputFormat='mp3', VoiceId='Joey')# Input result from polly
    print(response)

    if 'AudioStream' in response:
        with closing(response['AudioStream']) as stream:            # extract audio stream from response as a stream & in output is the path for tempdir and name of file from polly
            output = os.path.join(gettempdir(), 'speech.mp3')
            try: # to open output path in a file
                with open(output,'wb') as file:
                    file.write(stream.read())
            except IOError as error:
                print(error)
                sys.exit(-1)
    else :
       print('Could not find the stream') 
       sys.exit(-1)

    if sys.platform=='win32' : # To open it in system media player
        os.startfile(output)

btnRead = tk.Button(root,height=1,width=10,text='Read',command=getText) 
btnRead.pack()   

root.mainloop()  # Keeps the window open until its manually closed